import static java.lang.System.in;
import java.util.Scanner;
import java.math.BigInteger;
public class Main {
 public static void main(String[] args){
  Scanner in = new Scanner(System.in);
  int n; n = in.nextInt();
  BigInteger A =  in.nextBigInteger();
  A  = BigInteger.valueOf(54);
  A  = new BigInteger(“54244413433”);
  String z = A.toString();  intValue();
  BigInteger C = A.add(B);multiply(B);divide(B);
  subtract(B);
  gcd(B); max(B); mod(B); modInverse(mod);
  or(B); pow(B); sqrt(); xor(B);
  BigInteger fact = BigInteger.valueOf(1);
  if (a < b); if(A.compareTo(B) < 0);
  for(int i = 2; i <= 100; i++){
     BigInteger val = BigInteger.valueOf(i);
     fact = fact.multiply(val);
     System.out.println(fact);
  }
 }
}
